package com.project.game;

public class Tank {
    public String name;

    public Tank(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }


}
